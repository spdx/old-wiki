See the SPDX Tools documentation located at http://spdx.org/wiki/draft-spdx-tool-doc-beta for usage information.

See the NOTICE file for licensing information.