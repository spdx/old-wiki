# Contributing

When contributing to this repository, please first discuss the change you wish to make via SPDX technical mailing list <spdx-tech@lists.spdx.org>