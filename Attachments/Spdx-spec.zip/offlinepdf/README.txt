May 12, 2019

This directory contains the scripts used to generate the PDF version of the 2.1 SPDX Specfication.

The conversion was done offline using pandoc and wkhtmltopdf.

There were some issues that needed to be addressed and most but not all were resolved:

1. There was no index.md as part of the 2.1 branch. I added that in. Not sure if this was suppossed to be generic for
   all versions but as it has the version and contreibutors it seems specific. 

2. The chapter md files had links in some cases to other chapter md files. In creating the PDF I could not figue out how 
   to keep those so they would also work with the online HTML generation. For this release, I removed them.

3. I wanted to have a page break in between chapters. I tried inserting an HTML page break (see htmlpgbreak.txt) but met with
   limited success.

4. I generated a cover page using cover.html.

5. Good PDF generation requires a CSS styled for PDF. I took one from Githib (see tmp.css) and it worked liked a charm.


To create the document we 

1. Combine all the MD files into a single MD document in the correct order using mkmd.bat

2. We then use mkhtml.bat which uses pandoc to create an HTML version of the specification.

3. The HTML is then coverted to PDF using pubpdf.bat which runs wkyhtmltopdf.


